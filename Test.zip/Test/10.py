class Overloading():
    def __init__(self,*args):
        print(*args)

obj=Overloading(12)
obj=Overloading(10,43)
