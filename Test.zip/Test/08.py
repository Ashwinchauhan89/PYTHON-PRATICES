principle= float(input("Enter the principal :"))
rate = float(input("Enter the rate :"))
time = float(input("Enter the time :"))

si=(principle+rate+time)/100

print("Simple Interest ",si)