a=int(input("Enter any Number : "))

for i in range (1,11):
    print(a,"*",i,"=",a*i)