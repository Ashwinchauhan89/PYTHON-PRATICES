class A():
    def __init__(self,name,age):  # Paremeterized Construction
        self.name= name
        self.age = age

obj=A("Ashwin ","15")
print(obj.name)
print(obj.age)