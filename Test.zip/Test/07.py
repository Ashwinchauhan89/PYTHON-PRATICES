a=int(input("first :"))
b=int(input("second :"))
c=int(input("third :"))
res=[a,b,c]

res.sort()
print(res)
