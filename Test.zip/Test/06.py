a=str(input("Enter the string :"))
if (a=="a" or a=="e" or a=="o" or a=="i" or a=="u"):
    print("Vowels")

else:
    print("Consonants")