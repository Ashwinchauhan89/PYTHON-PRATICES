a=int(input("Enter the First number : "))
b=int(input("Enter the Second number : "))
c=int(input("Enter the Third number : "))

if (a>b and a>c):
    print("A is greater")

elif (b>a and b>c):
    print("B is greater")

else: 
    print("C is greater")